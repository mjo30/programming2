Name : Min Kyung Jo, Jeung Moon Lee
Email address : minkyung.jo@gatech.edu / jlee3120@gatech.edu
Date : 11/11/2018
Assignment Title : Project 2 Milestone 2

star_node.py contains all the methods including the main method. 
sample.txt contains the possible output from running star_node.py

To run this program, you can either run locally or use networklab.cc.gatech.edu.
You can make a star-node by entering : python star_node.py <Name of the node> <port number> <ip address of PoC> <port number of PoC><number of nodes in this star-node>
After creating the star-node, you can type 'help' to see all possible commands. 

Note : PoC stands for Point of Contact

Since this is a preliminary implementation, it does not handle cases when packet is lost or a node goes inactive. 
Also, the name of the node should be no longer than 10 characters. 
The file name, including the file path, should be no longer than 30 characters. 



